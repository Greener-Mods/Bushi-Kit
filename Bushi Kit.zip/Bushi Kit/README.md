INSTALLATION 
                 
This kit has been created and tested with BGEE and BG2EE. 

This is a WEIDU mod thus currently is compatible with other mods.

	1 - Extract the contents of the zip file into your override folder

	2 - Run WeiDU and install

BUSHI KIT DESCRIPTION

BUSHI: Bushi are masterless warriors, men without ties to a lord, temple, or monastery. They are commonly mercenaries, bandits highwaymen, or wanderers, earning their money however then can. They can be found serving samurai, protecting the court, or swelling the ranks of armies. A few may be kensai who have fallen by the way. Most, however are men of low birth who have chosen the way of the warrior to advance in the world.

Advantages:
- Starts with a +1 bonus to Armor Class and gains an additional +1 bonus every 5 levels thereafter.
- May use Kai ability once per day. Gains one use at level 1 and an additional use every 4 levels thereafter.

KAI: For 1 turn, the Bushi raises his effective level by two and gains a +2 bonus to hit, +10 temporary Hit Points and +2 bonus to all Saving Throws.

Disadvantages:
- May not wear armour heavier than splint mail.
- May not exceed Specialization (two slots) in any weapon class or fighting style.

FUTURE  CHANGES  

Add Bush kit to Yoshimo

COPYRIGHT

It can be used by anyone, at any time, anywhere at your own risk

THANK YOU to all that have assisted along the way